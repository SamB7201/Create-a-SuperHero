﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SuperheroAssn.Models
{
    public class Hero
    {
        public class ValidateDateRange : ValidationAttribute
        {
            protected override ValidationResult IsValid(object value, ValidationContext validationContext)
            {
                // your validation logic
                if ((DateTime)value >= Convert.ToDateTime("12/31/1969"))
                {
                    return ValidationResult.Success;
                }
                else
                {
                    return new ValidationResult("Date must be after Dec 31, 1969");
                }
            }
        }

        public class ValidateDataReuse : ValidationAttribute
        {
            protected override ValidationResult IsValid(object value, ValidationContext validationContext)
            {
                // your validation logic
                if (!value.Equals("Necromancy"))
                {
                    return ValidationResult.Success;
                }
                else
                {
                    return new ValidationResult("Powers must not repeat");
                }
            }
        }


        [Required]
        [MinLength(5, ErrorMessage = "Name must be longer than 5 charaters")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Origin is required")]
        public string Origin { get; set; }

        [Required(ErrorMessage = "Date of Birth is required")]
        [ValidateDateRange]
        public DateTime DoB { get; set; }

        [Required(ErrorMessage = "Power1 is required")]
        public string Power1 { get; set; }

        [Required(ErrorMessage = "Power2 is required")]
        [ValidateDataReuse]
        public string Power2 { get; set; }

        [Required(ErrorMessage = "Weakness is required")]
        public string Weakness { get; set; }

        [Required(ErrorMessage = "Color is required")]
        public string Color { get; set; }

        public List<SelectListItem> powers { get; set; }
        = new List<SelectListItem>
        {
            new SelectListItem{Value = "Flight"},
            new SelectListItem{Value = "Super Strength"},
            new SelectListItem{Value = "Super Speed"},
            new SelectListItem{Value = "Lazer Vision"},
            new SelectListItem{Value = "Bulletproof"},
            new SelectListItem{Value = "Invisibility"},
            new SelectListItem{Value = "Teleportation"},
            new SelectListItem{Value = "Time Control"},
            new SelectListItem{Value = "Regeneration"},
            new SelectListItem{Value = "Necromancy"}
        };

        public List<SelectListItem> weak { get; set; }
        = new List<SelectListItem>
        {
            new SelectListItem{Value = "Mental Attacks"},
            new SelectListItem{Value = "Fire"},
            new SelectListItem{Value = "Loud Noises"},
            new SelectListItem{Value = "Slow"},
            new SelectListItem{Value = "Untrusting"},
            new SelectListItem{Value = "Cowardly"},
            new SelectListItem{Value = "Frost"},
            new SelectListItem{Value = "Bullets"},
            new SelectListItem{Value = "Glue"},
            new SelectListItem{Value = "Electricity"}
        };
    }
}
