﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SuperheroAssn.Models
{
    public class AllHeros
    {
        private static List<Hero> heros = new List<Hero>();
        public static IEnumerable<Hero> ListHeros
        {
            get { return heros; }
        }
        public static void AddHero(Hero newHero)
        {
            heros.Add(newHero);
        }
    }
}
